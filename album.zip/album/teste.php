<?php

$fotos = [
    '../upload/1.jpg',
    '../upload/2.jpg'
]




?>